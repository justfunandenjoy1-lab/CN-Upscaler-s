# CN Upscaler — On-Device ONNX Super-Resolution Model Placement Guide

CN Upscaler executes **genuine on-device AI super-resolution** via **ONNX Runtime Android** (`com.microsoft.onnxruntime:onnxruntime-android`).
In compliance with strict engineering honesty rules, CN Upscaler **never** bundles a fake/synthetic model file and **never** silently falls back to ordinary `Bitmap` resizing when a genuine model file is absent.

## Supported Verified Models

| Model ID | Filename | Architecture | Native Scale | Input Tensor | Normalization | Output Tensor | License |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `realesrgan_x4plus` | `RealESRGAN_x4plus.onnx` | `RRDBNet` (23 RRDB blocks, 64 nf, 32 gc) | `4×` | `FLOAT32 [1, 3, H, W]` (`NCHW`, `RGB`) | `[0.0, 1.0]` (`pixel / 255.0f`) | `FLOAT32 [1, 3, H*4, W*4]` (`NCHW`, `RGB`) | BSD-3-Clause (`xinntao/Real-ESRGAN`) |
| `realesr_general_x4v3` | `realesr-general-x4v3.onnx` | `SRVGGNetCompact` (32 conv layers, 64 nf) | `4×` | `FLOAT32 [1, 3, H, W]` (`NCHW`, `RGB`) | `[0.0, 1.0]` (`pixel / 255.0f`) | `FLOAT32 [1, 3, H*4, W*4]` (`NCHW`, `RGB`) | BSD-3-Clause (`xinntao/Real-ESRGAN`) |

## Option A: Bundle Model at Build Time (Android Studio)
Place one or both legally obtained ONNX model files directly into this directory before building the APK/AAB:
- `app/src/main/assets/models/RealESRGAN_x4plus.onnx`
- `app/src/main/assets/models/realesr-general-x4v3.onnx`

Because `app/build.gradle.kts` specifies `noCompress += listOf("onnx", "ort", "tflite")`, the model can be streamed or copied to app-private storage (`context.filesDir/models/`) for memory-mapped ONNX Runtime execution.

## Option B: Import Model On-Device at Runtime (No Rebuild Needed)
1. Launch **CN Upscaler** on your Android device.
2. Open **Settings → AI Model Management → Import ONNX Model (.onnx)**.
3. Select `RealESRGAN_x4plus.onnx` or `realesr-general-x4v3.onnx` from device storage via Android's Storage Access Framework.
4. `OnnxModelVerifier` validates the ONNX graph signature (`[1, 3, H, W]` -> `[1, 3, 4H, 4W]`), records the SHA-256 digest, and immediately enables AI Super-Resolution processing.
