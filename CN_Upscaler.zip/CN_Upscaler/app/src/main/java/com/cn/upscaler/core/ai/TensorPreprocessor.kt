package com.cn.upscaler.core.ai

import kotlin.math.roundToInt

/**
 * Prepared NCHW Float32 tensor payload ready for ONNX Runtime inference,
 * along with padding metadata and separated alpha channel if present.
 */
data class PreparedTileTensor(
    val floatData: FloatArray,
    val tensorShape: LongArray, // [1, 3, paddedHeight, paddedWidth]
    val originalWidth: Int,
    val originalHeight: Int,
    val paddedWidth: Int,
    val paddedHeight: Int,
    val padRight: Int,
    val padBottom: Int,
    val alphaChannel: IntArray? // Original [originalHeight * originalWidth] alpha [0..255] if hasAlpha
)

/**
 * Exact model-compliant preprocessing and postprocessing for Real-ESRGAN / SRVGGNet ONNX models:
 * - Converts ARGB_8888 pixels to RGB (or BGR if specified by model spec).
 * - Pads spatial dimensions (width, height) to a multiple of `spatialAlignmentMultiple` (4)
 *   using symmetric reflection padding (`REFLECT_101`) to avoid border artifacts.
 * - Normalizes 8-bit channels [0..255] to float32 [normalizationMin..normalizationMax] ([0.0f..1.0f]).
 * - Converts layout from interleaved pixel order (NHWC) to planar NCHW `[1, 3, H, W]`.
 * - Reconstructs output NCHW `[1, 3, H*scale, W*scale]` back to unpadded ARGB_8888 pixels
 *   with bicubic-interpolated alpha channel restoration when transparency is present.
 */
object TensorPreprocessor {

    fun computeAlignedDimension(dimension: Int, multiple: Int = 4): Int {
        require(dimension > 0) { "Dimension must be positive ($dimension)" }
        require(multiple > 0) { "Alignment multiple must be positive ($multiple)" }
        val remainder = dimension % multiple
        return if (remainder == 0) dimension else dimension + (multiple - remainder)
    }

    /**
     * Reflect-101 index mapping for boundary padding without edge duplication seams.
     */
    fun reflectIndex(index: Int, length: Int): Int {
        if (length <= 1) return 0
        var idx = index
        while (idx < 0 || idx >= length) {
            idx = if (idx < 0) -idx else 2 * length - 2 - idx
        }
        return idx.coerceIn(0, length - 1)
    }

    fun preprocessTile(
        argbPixels: IntArray,
        width: Int,
        height: Int,
        spec: SuperResolutionModelSpec,
        preserveAlpha: Boolean = false
    ): PreparedTileTensor {
        require(width > 0 && height > 0) { "Tile dimensions must be positive (${width}x${height})" }
        require(argbPixels.size == width * height) {
            "Pixel buffer size (${argbPixels.size}) does not match ${width}x${height}"
        }

        val paddedW = computeAlignedDimension(width, spec.spatialAlignmentMultiple)
        val paddedH = computeAlignedDimension(height, spec.spatialAlignmentMultiple)
        val padRight = paddedW - width
        val padBottom = paddedH - height

        val planeSize = paddedW * paddedH
        val tensorData = FloatArray(3 * planeSize)
        val alphaBuffer = if (preserveAlpha) IntArray(width * height) else null

        val normRange = spec.normalizationMax - spec.normalizationMin
        val scaleFactor = normRange / 255.0f
        val offset = spec.normalizationMin

        val c0Offset = 0
        val c1Offset = planeSize
        val c2Offset = 2 * planeSize

        for (py in 0 until paddedH) {
            val sy = reflectIndex(py, height)
            val srcRowOffset = sy * width
            val dstRowOffset = py * paddedW
            for (px in 0 until paddedW) {
                val sx = reflectIndex(px, width)
                val argb = argbPixels[srcRowOffset + sx]

                val a = (argb ushr 24) and 0xFF
                val r = (argb ushr 16) and 0xFF
                val g = (argb ushr 8) and 0xFF
                val b = argb and 0xFF

                if (alphaBuffer != null && py < height && px < width) {
                    alphaBuffer[py * width + px] = a
                }

                val rf = r * scaleFactor + offset
                val gf = g * scaleFactor + offset
                val bf = b * scaleFactor + offset

                val dstIdx = dstRowOffset + px
                if (spec.channelOrder == ColorChannelOrder.RGB) {
                    tensorData[c0Offset + dstIdx] = rf
                    tensorData[c1Offset + dstIdx] = gf
                    tensorData[c2Offset + dstIdx] = bf
                } else {
                    tensorData[c0Offset + dstIdx] = bf
                    tensorData[c1Offset + dstIdx] = gf
                    tensorData[c2Offset + dstIdx] = rf
                }
            }
        }

        return PreparedTileTensor(
            floatData = tensorData,
            tensorShape = longArrayOf(1L, 3L, paddedH.toLong(), paddedW.toLong()),
            originalWidth = width,
            originalHeight = height,
            paddedWidth = paddedW,
            paddedHeight = paddedH,
            padRight = padRight,
            padBottom = padBottom,
            alphaChannel = alphaBuffer
        )
    }

    /**
     * Converts output NCHW tensor `[1, 3, paddedH * scale, paddedW * scale]` to unpadded
     * ARGB_8888 pixels `[originalH * scale, originalW * scale]`.
     */
    fun postprocessTile(
        outputTensorData: FloatArray,
        prepared: PreparedTileTensor,
        spec: SuperResolutionModelSpec
    ): IntArray {
        val scale = spec.nativeScale
        val outPaddedW = prepared.paddedWidth * scale
        val outPaddedH = prepared.paddedHeight * scale
        val outValidW = prepared.originalWidth * scale
        val outValidH = prepared.originalHeight * scale

        val planeSize = outPaddedW * outPaddedH
        require(outputTensorData.size >= 3 * planeSize) {
            "Output tensor size (${outputTensorData.size}) smaller than expected 3x${outPaddedH}x${outPaddedW}"
        }

        val upscaledAlpha = prepared.alphaChannel?.let { alpha ->
            upscaleSingleChannelBilinear(
                src = alpha,
                srcW = prepared.originalWidth,
                srcH = prepared.originalHeight,
                dstW = outValidW,
                dstH = outValidH
            )
        }

        val outPixels = IntArray(outValidW * outValidH)
        val outMin = spec.outputMin
        val outRange = (spec.outputMax - spec.outputMin).coerceAtLeast(1e-6f)

        val c0Offset = 0
        val c1Offset = planeSize
        val c2Offset = 2 * planeSize

        for (y in 0 until outValidH) {
            val tensorRowOffset = y * outPaddedW
            val outRowOffset = y * outValidW
            for (x in 0 until outValidW) {
                val tIdx = tensorRowOffset + x
                val v0 = ((outputTensorData[c0Offset + tIdx] - outMin) / outRange).coerceIn(0.0f, 1.0f)
                val v1 = ((outputTensorData[c1Offset + tIdx] - outMin) / outRange).coerceIn(0.0f, 1.0f)
                val v2 = ((outputTensorData[c2Offset + tIdx] - outMin) / outRange).coerceIn(0.0f, 1.0f)

                val ch0 = (v0 * 255.0f + 0.5f).toInt().coerceIn(0, 255)
                val ch1 = (v1 * 255.0f + 0.5f).toInt().coerceIn(0, 255)
                val ch2 = (v2 * 255.0f + 0.5f).toInt().coerceIn(0, 255)

                val r: Int
                val g = ch1
                val b: Int
                if (spec.channelOrder == ColorChannelOrder.RGB) {
                    r = ch0
                    b = ch2
                } else {
                    b = ch0
                    r = ch2
                }

                val a = upscaledAlpha?.get(outRowOffset + x) ?: 0xFF
                outPixels[outRowOffset + x] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return outPixels
    }

    private fun upscaleSingleChannelBilinear(
        src: IntArray,
        srcW: Int,
        srcH: Int,
        dstW: Int,
        dstH: Int
    ): IntArray {
        val dst = IntArray(dstW * dstH)
        val xRatio = if (dstW > 1) (srcW - 1).toFloat() / (dstW - 1).toFloat() else 0f
        val yRatio = if (dstH > 1) (srcH - 1).toFloat() / (dstH - 1).toFloat() else 0f

        for (y in 0 until dstH) {
            val gy = y * yRatio
            val y0 = gy.toInt().coerceIn(0, srcH - 1)
            val y1 = (y0 + 1).coerceIn(0, srcH - 1)
            val wy = gy - y0
            for (x in 0 until dstW) {
                val gx = x * xRatio
                val x0 = gx.toInt().coerceIn(0, srcW - 1)
                val x1 = (x0 + 1).coerceIn(0, srcW - 1)
                val wx = gx - x0

                val top = src[y0 * srcW + x0] * (1f - wx) + src[y0 * srcW + x1] * wx
                val bot = src[y1 * srcW + x0] * (1f - wx) + src[y1 * srcW + x1] * wx
                val value = (top * (1f - wy) + bot * wy).roundToInt().coerceIn(0, 255)
                dst[y * dstW + x] = value
            }
        }
        return dst
    }
}
