package com.cn.upscaler.feature.results

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.designsystem.MetricPill
import com.cn.upscaler.core.designsystem.StatusBadge
import com.cn.upscaler.core.designsystem.WarningBanner
import com.cn.upscaler.core.designsystem.formatBytes
import com.cn.upscaler.core.image.SafeBitmapDecoder
import com.cn.upscaler.domain.model.UpscaleJob
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ResultsScreen(
    job: UpscaleJob?,
    bitmapDecoder: SafeBitmapDecoder,
    onShare: (UpscaleJob) -> Unit,
    onOpenExternal: (UpscaleJob) -> Unit
) {
    if (job == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a completed job from History or Processing to inspect results.")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = job.originalFilename,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f)
            )
            StatusBadge(job.status)
        }

        // Interactive Before-and-After Split Comparison View
        BeforeAfterComparisonCard(
            beforeUriString = job.inputUriString,
            afterUriString = job.outputUriString ?: job.inputUriString,
            bitmapDecoder = bitmapDecoder
        )

        // Gallery Action Buttons
        if (job.outputUriString != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onShare(job) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share Image")
                }
                OutlinedButton(
                    onClick = { onOpenExternal(job) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open in Gallery")
                }
            }
        }

        // Provenance & Technical Details Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("AI Super-Resolution & Provenance Details", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricPill("Original", "${job.originalWidth} × ${job.originalHeight}")
                    MetricPill("Output", "${job.outputWidth ?: "-"} × ${job.outputHeight ?: "-"}")
                    MetricPill("Target", job.targetResolution.shortLabel)
                    MetricPill("AI Profile", job.enhancementLevel.displayName)
                    MetricPill("Format", job.outputFormat.displayName)
                    MetricPill("Output Size", formatBytes(job.outputFileSizeBytes ?: 0L))
                    job.durationMillis?.let { ms ->
                        MetricPill("Duration", String.format("%.2f s", ms / 1000.0))
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Actual AI Model: ${job.actualModelName ?: "N/A"} (${job.actualModelVersion ?: "-"})",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Execution Provider: ${job.activeExecutionProvider ?: "N/A"}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Processing Stages: ${job.actualProcessingStages ?: "N/A"}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (!job.warningsSummary.isNullOrBlank()) {
            WarningBanner(
                title = "Processing Advisories",
                messages = job.warningsSummary.split(" | ")
            )
        }
    }
}

@Composable
private fun BeforeAfterComparisonCard(
    beforeUriString: String,
    afterUriString: String,
    bitmapDecoder: SafeBitmapDecoder
) {
    var splitFraction by remember { mutableFloatStateOf(0.5f) }
    var beforeBitmap by remember(beforeUriString) { mutableStateOf<Bitmap?>(null) }
    var afterBitmap by remember(afterUriString) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(beforeUriString, afterUriString) {
        withContext(Dispatchers.IO) {
            val bRes = bitmapDecoder.decodeThumbnail(Uri.parse(beforeUriString), maxDimensionPx = 1024)
            if (bRes is AppResult.Success) beforeBitmap = bRes.data
            val aRes = bitmapDecoder.decodeThumbnail(Uri.parse(afterUriString), maxDimensionPx = 1024)
            if (aRes is AppResult.Success) afterBitmap = aRes.data
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Before (Original)", style = MaterialTheme.typography.labelMedium)
                Text("Interactive Split Comparison", fontWeight = FontWeight.SemiBold)
                Text("After (AI Enhanced)", style = MaterialTheme.typography.labelMedium)
            }
            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F172A))
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { change, _ ->
                            val w = size.width.toFloat().coerceAtLeast(1f)
                            splitFraction = (change.position.x / w).coerceIn(0.02f, 0.98f)
                        }
                    }
            ) {
                val bBmp = beforeBitmap
                val aBmp = afterBitmap
                if (bBmp != null && aBmp != null) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasW = size.width.roundToInt()
                        val canvasH = size.height.roundToInt()
                        val dstSize = IntSize(canvasW, canvasH)

                        // Draw full "After" image underneath
                        drawImage(
                            image = aBmp.asImageBitmap(),
                            dstOffset = IntOffset.Zero,
                            dstSize = dstSize
                        )

                        // Clip left region to splitFraction and draw "Before" image
                        val splitX = size.width * splitFraction
                        clipRect(left = 0f, top = 0f, right = splitX, bottom = size.height) {
                            drawImage(
                                image = bBmp.asImageBitmap(),
                                dstOffset = IntOffset.Zero,
                                dstSize = dstSize
                            )
                        }

                        // Draw vertical split divider line
                        drawLine(
                            color = Color.White,
                            start = Offset(splitX, 0f),
                            end = Offset(splitX, size.height),
                            strokeWidth = 4f
                        )
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Loading comparison preview...", color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Slider(
                value = splitFraction,
                onValueChange = { splitFraction = it },
                valueRange = 0.02f..0.98f
            )
        }
    }
}
