package com.cn.upscaler.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.ai.SupportedModelCatalog
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.metadata.UserMetadataConfig
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.core.processing.TargetResolution
import com.cn.upscaler.domain.model.AppSettings
import com.cn.upscaler.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "cn_upscaler_settings")

class SettingsRepository(
    private val context: Context
) {
    private object Keys {
        val TARGET_RESOLUTION = stringPreferencesKey("default_target_resolution")
        val ENHANCEMENT_LEVEL = stringPreferencesKey("default_enhancement_level")
        val OUTPUT_FORMAT = stringPreferencesKey("default_output_format")
        val JPEG_QUALITY = intPreferencesKey("jpeg_quality")
        val PREFERRED_MODEL_ID = stringPreferencesKey("preferred_model_id")
        val EXECUTION_PROVIDER = stringPreferencesKey("execution_provider")
        val TILE_SIZE = intPreferencesKey("tile_size")
        val TILE_OVERLAP = intPreferencesKey("tile_overlap")
        val ENABLE_MULTIPASS_8X = booleanPreferencesKey("enable_multipass_8x")
        val ENABLE_DENOISE = booleanPreferencesKey("enable_denoise")
        val DENOISE_STRENGTH = floatPreferencesKey("denoise_strength")
        val ENABLE_SHARPEN = booleanPreferencesKey("enable_sharpen")
        val SHARPEN_AMOUNT = floatPreferencesKey("sharpen_amount")
        val META_TITLE = stringPreferencesKey("meta_title")
        val META_AUTHOR = stringPreferencesKey("meta_author")
        val META_DESCRIPTION = stringPreferencesKey("meta_description")
        val META_KEYWORDS = stringPreferencesKey("meta_keywords")
        val META_COPYRIGHT = stringPreferencesKey("meta_copyright")
        val PRESERVE_ORIGINAL_EXIF = booleanPreferencesKey("preserve_original_exif")
        val STRIP_SENSITIVE_GPS = booleanPreferencesKey("strip_sensitive_gps")
        val THEME_MODE = stringPreferencesKey("theme_mode")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            defaultTargetResolution = TargetResolution.fromId(
                prefs[Keys.TARGET_RESOLUTION] ?: TargetResolution.UHD_4K.id
            ),
            defaultEnhancementLevel = EnhancementLevel.fromId(
                prefs[Keys.ENHANCEMENT_LEVEL] ?: EnhancementLevel.LEVEL_4X.id
            ),
            defaultOutputFormat = runCatching {
                ImageFormat.valueOf(prefs[Keys.OUTPUT_FORMAT] ?: ImageFormat.JPEG.name)
            }.getOrDefault(ImageFormat.JPEG),
            jpegQuality = (prefs[Keys.JPEG_QUALITY] ?: 95).coerceIn(80, 100),
            preferredModelId = prefs[Keys.PREFERRED_MODEL_ID] ?: SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.id,
            executionProvider = ExecutionProviderPreference.fromId(
                prefs[Keys.EXECUTION_PROVIDER] ?: ExecutionProviderPreference.AUTO.id
            ),
            tileSize = (prefs[Keys.TILE_SIZE] ?: 256).coerceIn(128, 512),
            tileOverlap = (prefs[Keys.TILE_OVERLAP] ?: 32).coerceIn(16, 64),
            enableMultiPass8x = prefs[Keys.ENABLE_MULTIPASS_8X] ?: true,
            postProcessingConfig = PostProcessingConfig(
                enableSubtleDenoise = prefs[Keys.ENABLE_DENOISE] ?: false,
                denoiseStrength = (prefs[Keys.DENOISE_STRENGTH] ?: 0.25f).coerceIn(0f, 1f),
                enableUnsharpMask = prefs[Keys.ENABLE_SHARPEN] ?: false,
                sharpenAmount = (prefs[Keys.SHARPEN_AMOUNT] ?: 0.20f).coerceIn(0f, 0.50f)
            ),
            userMetadataConfig = UserMetadataConfig(
                title = prefs[Keys.META_TITLE].orEmpty(),
                author = prefs[Keys.META_AUTHOR].orEmpty(),
                description = prefs[Keys.META_DESCRIPTION].orEmpty(),
                keywords = prefs[Keys.META_KEYWORDS].orEmpty(),
                copyright = prefs[Keys.META_COPYRIGHT].orEmpty(),
                preserveSafeOriginalExif = prefs[Keys.PRESERVE_ORIGINAL_EXIF] ?: true,
                stripSensitiveLocationMetadata = prefs[Keys.STRIP_SENSITIVE_GPS] ?: true
            ),
            themeMode = ThemeMode.fromId(prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.id)
        )
    }

    suspend fun getCurrentSettings(): AppSettings = settingsFlow.first()

    suspend fun updateTargetResolution(target: TargetResolution) {
        context.dataStore.edit { it[Keys.TARGET_RESOLUTION] = target.id }
    }

    suspend fun updateEnhancementLevel(level: EnhancementLevel) {
        context.dataStore.edit { it[Keys.ENHANCEMENT_LEVEL] = level.id }
    }

    suspend fun updateOutputFormat(format: ImageFormat, jpegQuality: Int) {
        context.dataStore.edit {
            it[Keys.OUTPUT_FORMAT] = format.name
            it[Keys.JPEG_QUALITY] = jpegQuality.coerceIn(80, 100)
        }
    }

    suspend fun updateExecutionProvider(provider: ExecutionProviderPreference) {
        context.dataStore.edit { it[Keys.EXECUTION_PROVIDER] = provider.id }
    }

    suspend fun updateTileSettings(tileSize: Int, overlap: Int) {
        context.dataStore.edit {
            it[Keys.TILE_SIZE] = tileSize.coerceIn(128, 512)
            it[Keys.TILE_OVERLAP] = overlap.coerceIn(16, (tileSize / 3).coerceAtMost(64))
        }
    }

    suspend fun updatePreferredModel(modelId: String) {
        context.dataStore.edit { it[Keys.PREFERRED_MODEL_ID] = modelId }
    }

    suspend fun updatePostProcessing(config: PostProcessingConfig) {
        context.dataStore.edit {
            it[Keys.ENABLE_DENOISE] = config.enableSubtleDenoise
            it[Keys.DENOISE_STRENGTH] = config.denoiseStrength
            it[Keys.ENABLE_SHARPEN] = config.enableUnsharpMask
            it[Keys.SHARPEN_AMOUNT] = config.sharpenAmount
        }
    }

    suspend fun updateUserMetadata(config: UserMetadataConfig) {
        context.dataStore.edit {
            it[Keys.META_TITLE] = config.title
            it[Keys.META_AUTHOR] = config.author
            it[Keys.META_DESCRIPTION] = config.description
            it[Keys.META_KEYWORDS] = config.keywords
            it[Keys.META_COPYRIGHT] = config.copyright
            it[Keys.PRESERVE_ORIGINAL_EXIF] = config.preserveSafeOriginalExif
            it[Keys.STRIP_SENSITIVE_GPS] = config.stripSensitiveLocationMetadata
        }
    }

    suspend fun updateThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.id }
    }
}
