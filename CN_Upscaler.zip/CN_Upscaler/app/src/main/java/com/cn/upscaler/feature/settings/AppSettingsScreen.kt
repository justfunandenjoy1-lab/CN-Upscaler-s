package com.cn.upscaler.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cn.upscaler.app.MainUiState
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.ai.ModelAvailability
import com.cn.upscaler.core.ai.SupportedModelCatalog
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.domain.model.ThemeMode

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppSettingsScreen(
    uiState: MainUiState,
    onImportModelClick: (String) -> Unit,
    onRefreshModels: () -> Unit,
    onUpdateExecutionProvider: (ExecutionProviderPreference) -> Unit,
    onUpdateTileSettings: (Int, Int) -> Unit,
    onUpdatePostProcessing: (PostProcessingConfig) -> Unit,
    onUpdateThemeMode: (ThemeMode) -> Unit
) {
    val settings = uiState.settings

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Application & Engine Settings", style = MaterialTheme.typography.titleLarge)

        // 1. AI Model Management & Import
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("On-Device ONNX AI Model Management", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))
                when (val avail = uiState.modelAvailability) {
                    is ModelAvailability.Available -> {
                        Text(
                            text = "Active Verified Model: ${avail.spec.displayName} (${avail.spec.version})",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "File: ${avail.modelFile.name} • SHA-256: ${avail.sha256Digest}",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    is ModelAvailability.Unavailable -> {
                        Text(
                            text = avail.reason,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                SupportedModelCatalog.ALL_SPECS.forEach { spec ->
                    Button(
                        onClick = { onImportModelClick(spec.id) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import ${spec.filename}")
                    }
                }
                OutlinedButton(
                    onClick = onRefreshModels,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Re-Verify Installed Models")
                }
            }
        }

        // 2. Hardware Acceleration
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Hardware Acceleration (ONNX Runtime)", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Selects the ONNX Runtime execution provider. Automatic falls back safely to multi-threaded CPU if NNAPI/GPU initialization fails.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                ExecutionProviderPreference.entries.forEach { pref ->
                    FilterChip(
                        selected = settings.executionProvider == pref,
                        onClick = { onUpdateExecutionProvider(pref) },
                        label = { Text(pref.displayName) },
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }

        // 3. Tile-Based Processing
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Tile-Based Memory & Seam Control", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Processes large images sequentially in overlapping tiles blended with a 2D raised-cosine window.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Tile Size: ${settings.tileSize} × ${settings.tileSize} px", style = MaterialTheme.typography.bodyMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(128, 192, 256, 384, 512).forEach { size ->
                        FilterChip(
                            selected = settings.tileSize == size,
                            onClick = { onUpdateTileSettings(size, settings.tileOverlap) },
                            label = { Text("${size}px") }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Tile Overlap (Cosine Feathering Margin): ${settings.tileOverlap} px", style = MaterialTheme.typography.bodyMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(16, 32, 48).forEach { overlap ->
                        FilterChip(
                            selected = settings.tileOverlap == overlap,
                            onClick = { onUpdateTileSettings(settings.tileSize, overlap) },
                            label = { Text("${overlap}px") }
                        )
                    }
                }
            }
        }

        // 4. Optional Conventional Post-Processing
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Optional Conventional Post-Processing", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Disabled by default to preserve natural neural textures. Note: AI Face Restoration is not installed and never faked via sharpening.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                val post = settings.postProcessingConfig
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Edge-Preserving Luminance Denoise")
                    Switch(
                        checked = post.enableSubtleDenoise,
                        onCheckedChange = { onUpdatePostProcessing(post.copy(enableSubtleDenoise = it)) }
                    )
                }
                if (post.enableSubtleDenoise) {
                    Text("Denoise Strength: ${String.format("%.2f", post.denoiseStrength)}")
                    Slider(
                        value = post.denoiseStrength,
                        onValueChange = { onUpdatePostProcessing(post.copy(denoiseStrength = it)) },
                        valueRange = 0.05f..0.80f
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Subtle Unsharp Mask (Capped at 0.50)")
                    Switch(
                        checked = post.enableUnsharpMask,
                        onCheckedChange = { onUpdatePostProcessing(post.copy(enableUnsharpMask = it)) }
                    )
                }
                if (post.enableUnsharpMask) {
                    Text("Sharpen Amount: ${String.format("%.2f", post.sharpenAmount)}")
                    Slider(
                        value = post.sharpenAmount,
                        onValueChange = { onUpdatePostProcessing(post.copy(sharpenAmount = it)) },
                        valueRange = 0.05f..0.50f
                    )
                }
            }
        }

        // 5. Theme Appearance
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Theme & Appearance", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onUpdateThemeMode(mode) },
                            label = { Text(mode.label) }
                        )
                    }
                }
            }
        }
    }
}
