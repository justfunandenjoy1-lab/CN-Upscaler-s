package com.cn.upscaler.app

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.ai.EnhancementProfile
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.ai.ModelAvailability
import com.cn.upscaler.core.ai.ModelCapabilities
import com.cn.upscaler.core.ai.SupportedModelCatalog
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.image.ImageValidationResult
import com.cn.upscaler.core.metadata.UserMetadataConfig
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.core.processing.TargetResolution
import com.cn.upscaler.domain.model.AppSettings
import com.cn.upscaler.domain.model.JobStatus
import com.cn.upscaler.domain.model.SelectedImageCandidate
import com.cn.upscaler.domain.model.ThemeMode
import com.cn.upscaler.domain.model.UpscaleJob
import com.cn.upscaler.worker.BatchUpscaleWorker
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(
    val settings: AppSettings = AppSettings(),
    val modelAvailability: ModelAvailability = ModelAvailability.Unavailable(
        expectedSpecs = SupportedModelCatalog.ALL_SPECS,
        checkedLocations = emptyList(),
        reason = "Checking installed ONNX models..."
    ),
    val modelCapabilities: ModelCapabilities = ModelCapabilities(
        primaryModelAvailable = false,
        primaryModelId = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.id,
        primaryModelName = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.displayName,
        primaryModelVersion = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.version,
        primaryNativeScale = 4,
        secondaryRefinementModelAvailable = false,
        secondaryModelId = null,
        supportsMultiPass8xProfile = false,
        supportsExtreme16xProfile = false
    ),
    val enhancementProfiles: List<EnhancementProfile> = emptyList(),
    val selectedCandidates: List<SelectedImageCandidate> = emptyList(),
    val activeQueue: List<UpscaleJob> = emptyList(),
    val historyJobs: List<UpscaleJob> = emptyList(),
    val focusedResultJobId: String? = null,
    val statusBannerMessage: String? = null
)

class MainViewModel(
    private val appContext: Context,
    private val container: AppContainer
) : ViewModel() {

    private val _selectedCandidates = MutableStateFlow<List<SelectedImageCandidate>>(emptyList())
    private val _modelAvailability = MutableStateFlow<ModelAvailability>(
        ModelAvailability.Unavailable(
            expectedSpecs = SupportedModelCatalog.ALL_SPECS,
            checkedLocations = emptyList(),
            reason = "Checking installed ONNX models..."
        )
    )
    private val _focusedResultJobId = MutableStateFlow<String?>(null)
    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    val uiState: StateFlow<MainUiState> = combine(
        container.settingsRepository.settingsFlow,
        _modelAvailability,
        _selectedCandidates,
        container.jobRepository.activeQueueFlow,
        container.jobRepository.historyFlow
    ) { settings, availability, candidates, activeQueue, history ->
        val capabilities = container.modelVerifier.resolveCapabilities(
            availability = availability,
            enableMultiPass8x = settings.enableMultiPass8x
        )
        val profiles = container.profileResolver.resolveProfiles(capabilities)
        MainUiState(
            settings = settings,
            modelAvailability = availability,
            modelCapabilities = capabilities,
            enhancementProfiles = profiles,
            selectedCandidates = candidates,
            activeQueue = activeQueue,
            historyJobs = history,
            focusedResultJobId = _focusedResultJobId.value,
            statusBannerMessage = _statusBannerMessage.value
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MainUiState()
    )

    init {
        refreshModelStatus()
    }

    fun refreshModelStatus() {
        viewModelScope.launch {
            val currentSettings = container.settingsRepository.getCurrentSettings()
            val availability = withContext(container.dispatchers.io) {
                container.modelVerifier.verifyInstalledModels(currentSettings.preferredModelId)
            }
            _modelAvailability.value = availability
        }
    }

    fun importOnnxModel(uri: Uri, targetModelId: String) {
        viewModelScope.launch {
            val spec = SupportedModelCatalog.findById(targetModelId)
            val result = withContext(container.dispatchers.io) {
                container.modelVerifier.importModelFromUri(uri, spec)
            }
            _modelAvailability.value = result
            when (result) {
                is ModelAvailability.Available -> {
                    container.settingsRepository.updatePreferredModel(spec.id)
                    _statusBannerMessage.value = "Verified ONNX model ${spec.displayName} (SHA-256: ${result.sha256Digest})."
                }
                is ModelAvailability.Unavailable -> {
                    _statusBannerMessage.value = result.reason
                }
            }
        }
    }

    fun clearBannerMessage() {
        _statusBannerMessage.value = null
    }

    fun onImagesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val inspected = withContext(container.dispatchers.io) {
                uris.map { uri ->
                    container.safUriPermissionManager.takePersistableReadPermissionIfSupported(uri)
                    when (val res = container.imageInspector.inspect(uri)) {
                        is ImageValidationResult.Valid -> SelectedImageCandidate(
                            id = UUID.randomUUID().toString(),
                            uriString = uri.toString(),
                            inspectionReport = res.report,
                            validationWarnings = res.warnings,
                            validationError = null
                        )
                        is ImageValidationResult.Invalid -> SelectedImageCandidate(
                            id = UUID.randomUUID().toString(),
                            uriString = uri.toString(),
                            inspectionReport = null,
                            validationWarnings = emptyList(),
                            validationError = res.reason
                        )
                    }
                }
            }
            val existingUris = _selectedCandidates.value.map { it.uriString }.toSet()
            val deduplicated = inspected.filter { it.uriString !in existingUris }
            _selectedCandidates.value = _selectedCandidates.value + deduplicated
        }
    }

    fun removeCandidate(candidateId: String) {
        _selectedCandidates.value = _selectedCandidates.value.filterNot { it.id == candidateId }
    }

    fun clearSelection() {
        _selectedCandidates.value = emptyList()
    }

    fun updateTargetResolution(target: TargetResolution) {
        viewModelScope.launch {
            container.settingsRepository.updateTargetResolution(target)
        }
    }

    fun updateEnhancementLevel(level: EnhancementLevel) {
        viewModelScope.launch {
            container.settingsRepository.updateEnhancementLevel(level)
        }
    }

    fun updateOutputFormat(format: ImageFormat, jpegQuality: Int) {
        viewModelScope.launch {
            container.settingsRepository.updateOutputFormat(format, jpegQuality)
        }
    }

    fun updateExecutionProvider(provider: ExecutionProviderPreference) {
        viewModelScope.launch {
            container.settingsRepository.updateExecutionProvider(provider)
        }
    }

    fun updateTileSettings(tileSize: Int, overlap: Int) {
        viewModelScope.launch {
            container.settingsRepository.updateTileSettings(tileSize, overlap)
        }
    }

    fun updatePostProcessing(config: PostProcessingConfig) {
        viewModelScope.launch {
            container.settingsRepository.updatePostProcessing(config)
        }
    }

    fun updateUserMetadata(config: UserMetadataConfig) {
        viewModelScope.launch {
            container.settingsRepository.updateUserMetadata(config)
        }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            container.settingsRepository.updateThemeMode(mode)
        }
    }

    fun enqueueSelectedBatch(onEnqueued: () -> Unit) {
        val validCandidates = _selectedCandidates.value.filter { it.isValid }
        if (validCandidates.isEmpty()) {
            _statusBannerMessage.value = "Please select at least one valid image before starting."
            return
        }

        viewModelScope.launch {
            val state = uiState.value
            if (!state.modelCapabilities.primaryModelAvailable) {
                _statusBannerMessage.value = "Cannot start AI processing: no verified ONNX super-resolution model is installed. Import RealESRGAN_x4plus.onnx in Settings."
                return@launch
            }
            val selectedProfile = state.enhancementProfiles.find { it.level == state.settings.defaultEnhancementLevel }
            if (selectedProfile != null && !selectedProfile.isAvailable) {
                _statusBannerMessage.value = selectedProfile.strategy.limitationNotice
                return@launch
            }

            container.jobRepository.enqueueBatch(
                candidates = validCandidates,
                targetResolution = state.settings.defaultTargetResolution,
                enhancementLevel = state.settings.defaultEnhancementLevel,
                outputFormat = state.settings.defaultOutputFormat,
                jpegQuality = state.settings.jpegQuality
            )
            _selectedCandidates.value = emptyList()
            BatchUpscaleWorker.enqueueOrContinueBatch(appContext)
            onEnqueued()
        }
    }

    fun cancelJob(jobId: String) {
        viewModelScope.launch {
            container.jobRepository.cancelJob(jobId)
        }
    }

    fun cancelAllJobs() {
        viewModelScope.launch {
            container.jobRepository.cancelAllActiveAndWaiting()
            BatchUpscaleWorker.cancelBatchWork(appContext)
        }
    }

    fun retryJob(jobId: String) {
        viewModelScope.launch {
            container.jobRepository.retryJob(jobId)
            BatchUpscaleWorker.enqueueOrContinueBatch(appContext)
        }
    }

    fun deleteHistoryJob(jobId: String) {
        viewModelScope.launch {
            container.jobRepository.deleteJob(jobId)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            container.jobRepository.clearHistory()
        }
    }

    fun focusResultJob(jobId: String) {
        _focusedResultJobId.value = jobId
    }

    fun shareOutput(job: UpscaleJob) {
        val outUri = job.outputUriString ?: return
        val intent = container.mediaStoreSaver.createShareImageIntent(
            Uri.parse(outUri),
            job.outputFormat.mimeType
        )
        appContext.startActivity(intent)
    }

    fun openOutput(job: UpscaleJob) {
        val outUri = job.outputUriString ?: return
        val intent = container.mediaStoreSaver.createOpenImageIntent(
            Uri.parse(outUri),
            job.outputFormat.mimeType
        )
        appContext.startActivity(intent)
    }

    companion object {
        fun provideFactory(app: CnUpscalerApplication): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MainViewModel(app.applicationContext, app.container) as T
                }
            }
    }
}
