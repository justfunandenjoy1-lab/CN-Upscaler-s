package com.cn.upscaler.core.image

enum class ImageFormat(
    val displayName: String,
    val mimeType: String,
    val fileExtension: String,
    val supportsTransparency: Boolean
) {
    JPEG("JPEG", "image/jpeg", "jpg", supportsTransparency = false),
    PNG("PNG", "image/png", "png", supportsTransparency = true),
    WEBP("WebP", "image/webp", "webp", supportsTransparency = true),
    UNKNOWN("Unknown", "application/octet-stream", "bin", supportsTransparency = false);

    companion object {
        fun fromMimeTypeOrName(mimeType: String?, filename: String?): ImageFormat {
            val normalizedMime = mimeType?.lowercase()?.trim().orEmpty()
            when {
                normalizedMime == "image/jpeg" || normalizedMime == "image/jpg" -> return JPEG
                normalizedMime == "image/png" -> return PNG
                normalizedMime == "image/webp" -> return WEBP
            }
            val ext = filename?.substringAfterLast('.', "")?.lowercase()?.trim().orEmpty()
            return when (ext) {
                "jpg", "jpeg" -> JPEG
                "png" -> PNG
                "webp" -> WEBP
                else -> UNKNOWN
            }
        }
    }
}
