package com.cn.upscaler.core.ai

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.Closeable
import java.nio.FloatBuffer
import java.util.Collections

/**
 * Abstraction for tile-level super-resolution inference so TileProcessor can be unit-tested
 * deterministically and backed by ONNX Runtime in production.
 */
interface TileSuperResolutionInferenceSession : Closeable {
    val modelSpec: SuperResolutionModelSpec
    val activeProviderReport: ActiveExecutionProviderReport

    /**
     * Runs genuine neural network super-resolution on a single RGB/ARGB tile of dimensions
     * `(tileWidth x tileHeight)` and returns an upscaled ARGB_8888 pixel array of dimensions
     * `(tileWidth * modelSpec.nativeScale) x (tileHeight * modelSpec.nativeScale)`.
     */
    fun inferTile(
        argbPixels: IntArray,
        tileWidth: Int,
        tileHeight: Int,
        preserveAlpha: Boolean
    ): IntArray
}

/**
 * Production ONNX Runtime Android inference engine.
 * Loads a verified `.onnx` model file into an `OrtSession` with configured hardware acceleration
 * (NNAPI / CPU fallback) and executes float32 NCHW tensor inference.
 */
class OnnxSuperResolutionEngine(
    private val verifier: OnnxModelVerifier
) {
    fun openSession(
        preferredModelId: String,
        executionPreference: ExecutionProviderPreference,
        cpuThreads: Int = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
    ): TileSuperResolutionInferenceSession {
        val availability = verifier.verifyInstalledModels(preferredModelId)
        if (availability !is ModelAvailability.Available) {
            val unavailable = availability as ModelAvailability.Unavailable
            throw IllegalStateException(unavailable.reason)
        }

        val env = OrtEnvironment.getEnvironment()
        val (options, providerReport) = HardwareAcceleratorManager.configureSessionOptions(
            preference = executionPreference,
            cpuThreadCount = cpuThreads
        )

        val session = try {
            env.createSession(availability.modelFile.absolutePath, options)
        } catch (accelError: Throwable) {
            // If NNAPI session creation fails on a specific device driver, retry cleanly with CPU_ONLY
            options.close()
            val (cpuOptions, cpuReport) = HardwareAcceleratorManager.configureSessionOptions(
                preference = ExecutionProviderPreference.CPU_ONLY,
                cpuThreadCount = cpuThreads
            )
            val fallbackSession = env.createSession(availability.modelFile.absolutePath, cpuOptions)
            return OrtTileInferenceSession(
                env = env,
                session = fallbackSession,
                options = cpuOptions,
                modelSpec = availability.spec,
                inputName = availability.inputTensorName,
                activeProviderReport = cpuReport.copy(
                    requestedPreference = executionPreference,
                    fellBackToCpu = true,
                    fallbackReason = "Driver rejected accelerated graph (${accelError.message}); fell back to CPU."
                )
            )
        }

        return OrtTileInferenceSession(
            env = env,
            session = session,
            options = options,
            modelSpec = availability.spec,
            inputName = availability.inputTensorName,
            activeProviderReport = providerReport
        )
    }

    private class OrtTileInferenceSession(
        private val env: OrtEnvironment,
        private val session: OrtSession,
        private val options: OrtSession.SessionOptions,
        override val modelSpec: SuperResolutionModelSpec,
        private val inputName: String,
        override val activeProviderReport: ActiveExecutionProviderReport
    ) : TileSuperResolutionInferenceSession {

        override fun inferTile(
            argbPixels: IntArray,
            tileWidth: Int,
            tileHeight: Int,
            preserveAlpha: Boolean
        ): IntArray {
            val prepared = TensorPreprocessor.preprocessTile(
                argbPixels = argbPixels,
                width = tileWidth,
                height = tileHeight,
                spec = modelSpec,
                preserveAlpha = preserveAlpha
            )

            val floatBuffer = FloatBuffer.wrap(prepared.floatData)
            OnnxTensor.createTensor(env, floatBuffer, prepared.tensorShape).use { inputTensor ->
                session.run(Collections.singletonMap(inputName, inputTensor)).use { result ->
                    val outputValue = result.get(0) as? OnnxTensor
                        ?: throw IllegalStateException("ONNX session did not return an OnnxTensor output.")
                    val outFloatBuffer = outputValue.floatBuffer
                    val outArray = FloatArray(outFloatBuffer.remaining())
                    outFloatBuffer.get(outArray)

                    return TensorPreprocessor.postprocessTile(
                        outputTensorData = outArray,
                        prepared = prepared,
                        spec = modelSpec
                    )
                }
            }
        }

        override fun close() {
            try {
                session.close()
            } catch (_: Throwable) {
            }
            try {
                options.close()
            } catch (_: Throwable) {
            }
        }
    }
}
