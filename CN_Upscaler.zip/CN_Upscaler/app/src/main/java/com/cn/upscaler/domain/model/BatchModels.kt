package com.cn.upscaler.domain.model

import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.ai.SupportedModelCatalog
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.image.ImageInspectionReport
import com.cn.upscaler.core.metadata.UserMetadataConfig
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.core.processing.TargetResolution

/**
 * Required Batch Job Statuses (Phase 13).
 */
enum class JobStatus {
    WAITING,
    PROCESSING,
    COMPLETED,
    FAILED,
    CANCELLED
}

/**
 * Selected candidate image in the Image Picker / Selection screen.
 */
data class SelectedImageCandidate(
    val id: String,
    val uriString: String,
    val inspectionReport: ImageInspectionReport?,
    val validationWarnings: List<String> = emptyList(),
    val validationError: String? = null
) {
    val isValid: Boolean get() = inspectionReport != null && validationError == null
}

/**
 * Complete representation of a queued, active, or historical super-resolution job.
 */
data class UpscaleJob(
    val id: String,
    val inputUriString: String,
    val outputUriString: String?,
    val originalFilename: String,
    val originalWidth: Int,
    val originalHeight: Int,
    val originalFormat: ImageFormat,
    val originalFileSizeBytes: Long,
    val hasAlpha: Boolean,
    val targetResolution: TargetResolution,
    val enhancementLevel: EnhancementLevel,
    val outputFormat: ImageFormat,
    val jpegQuality: Int,
    val status: JobStatus,
    val progress: Float, // 0.0f..1.0f
    val currentStageText: String,
    val createdAtMillis: Long,
    val startTimeMillis: Long?,
    val completionTimeMillis: Long?,
    val outputWidth: Int?,
    val outputHeight: Int?,
    val outputFileSizeBytes: Long?,
    val actualModelName: String?,
    val actualModelVersion: String?,
    val actualProcessingStages: String?,
    val activeExecutionProvider: String?,
    val errorDetails: String?,
    val warningsSummary: String?
) {
    val durationMillis: Long?
        get() = if (startTimeMillis != null && completionTimeMillis != null && completionTimeMillis >= startTimeMillis) {
            completionTimeMillis - startTimeMillis
        } else {
            null
        }
}

enum class ThemeMode(val id: String, val label: String) {
    SYSTEM("SYSTEM", "Follow System"),
    LIGHT("LIGHT", "Light Mode"),
    DARK("DARK", "Dark Mode");

    companion object {
        fun fromId(id: String): ThemeMode = entries.find { it.id == id } ?: SYSTEM
    }
}

data class AppSettings(
    val defaultTargetResolution: TargetResolution = TargetResolution.UHD_4K,
    val defaultEnhancementLevel: EnhancementLevel = EnhancementLevel.LEVEL_4X,
    val defaultOutputFormat: ImageFormat = ImageFormat.JPEG,
    val jpegQuality: Int = 95,
    val preferredModelId: String = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.id,
    val executionProvider: ExecutionProviderPreference = ExecutionProviderPreference.AUTO,
    val tileSize: Int = 256,
    val tileOverlap: Int = 32,
    val enableMultiPass8x: Boolean = true,
    val postProcessingConfig: PostProcessingConfig = PostProcessingConfig(),
    val userMetadataConfig: UserMetadataConfig = UserMetadataConfig(),
    val themeMode: ThemeMode = ThemeMode.SYSTEM
)
