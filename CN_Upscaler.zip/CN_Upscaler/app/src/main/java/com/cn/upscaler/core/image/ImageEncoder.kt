package com.cn.upscaler.core.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.common.ErrorCode
import java.io.File
import java.io.FileOutputStream

data class EncodingConfig(
    val format: ImageFormat = ImageFormat.JPEG,
    val jpegQuality: Int = DEFAULT_JPEG_QUALITY,
    val webpQuality: Int = 95
) {
    init {
        require(jpegQuality in MIN_JPEG_QUALITY..MAX_JPEG_QUALITY) {
            "JPEG quality ($jpegQuality) must be between $MIN_JPEG_QUALITY and $MAX_JPEG_QUALITY."
        }
    }

    companion object {
        const val MIN_JPEG_QUALITY = 80
        const val MAX_JPEG_QUALITY = 100
        const val DEFAULT_JPEG_QUALITY = 95
    }
}

data class EncodedImageVerification(
    val outputFile: File,
    val format: ImageFormat,
    val verifiedWidth: Int,
    val verifiedHeight: Int,
    val fileSizeBytes: Long,
    val transparencyPreserved: Boolean,
    val transparencyDiscardedWarning: String?
)

/**
 * Encodes processed Bitmaps to JPEG (quality 80-100, default 95), PNG, or WebP,
 * checks free storage space beforehand, and verifies the written file header afterward.
 */
object ImageEncoder {

    fun encodeToFile(
        bitmap: Bitmap,
        destFile: File,
        config: EncodingConfig,
        sourceHasAlpha: Boolean
    ): AppResult<EncodedImageVerification> {
        val usableSpace = destFile.parentFile?.usableSpace ?: Long.MAX_VALUE
        val minRequiredSpace = (bitmap.width.toLong() * bitmap.height.toLong() * 2L).coerceAtLeast(8L * 1024L * 1024L)
        if (usableSpace < minRequiredSpace) {
            return AppResult.Error(
                message = "Insufficient device storage space (${usableSpace / (1024 * 1024)} MB free).",
                errorCode = ErrorCode.INSUFFICIENT_STORAGE
            )
        }

        val transparencyWarning = if (sourceHasAlpha && !config.format.supportsTransparency) {
            "Source image contained alpha transparency, which was flattened because ${config.format.displayName} does not support transparency."
        } else {
            null
        }

        val compressFormat = resolveCompressFormat(config.format, config.webpQuality)
        val quality = when (config.format) {
            ImageFormat.JPEG -> config.jpegQuality.coerceIn(EncodingConfig.MIN_JPEG_QUALITY, EncodingConfig.MAX_JPEG_QUALITY)
            ImageFormat.PNG -> 100
            ImageFormat.WEBP -> config.webpQuality.coerceIn(80, 100)
            ImageFormat.UNKNOWN -> EncodingConfig.DEFAULT_JPEG_QUALITY
        }

        try {
            FileOutputStream(destFile).use { fos ->
                val ok = bitmap.compress(compressFormat, quality, fos)
                fos.flush()
                if (!ok) {
                    destFile.delete()
                    return AppResult.Error(
                        message = "Android Bitmap.compress failed for format ${config.format.displayName}.",
                        errorCode = ErrorCode.ENCODING_FAILED
                    )
                }
            }
        } catch (t: Throwable) {
            destFile.delete()
            return AppResult.Error(
                message = "I/O error while encoding image: ${t.message}",
                cause = t,
                errorCode = ErrorCode.ENCODING_FAILED
            )
        }

        // Verify actual encoded dimensions and format after writing output
        val verifyOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(destFile.absolutePath, verifyOptions)
        if (verifyOptions.outWidth != bitmap.width || verifyOptions.outHeight != bitmap.height) {
            return AppResult.Error(
                message = "Post-encode verification mismatch: expected ${bitmap.width}×${bitmap.height}, found ${verifyOptions.outWidth}×${verifyOptions.outHeight}.",
                errorCode = ErrorCode.ENCODING_FAILED
            )
        }

        return AppResult.Success(
            EncodedImageVerification(
                outputFile = destFile,
                format = config.format,
                verifiedWidth = verifyOptions.outWidth,
                verifiedHeight = verifyOptions.outHeight,
                fileSizeBytes = destFile.length(),
                transparencyPreserved = sourceHasAlpha && config.format.supportsTransparency,
                transparencyDiscardedWarning = transparencyWarning
            )
        )
    }

    @Suppress("DEPRECATION")
    private fun resolveCompressFormat(format: ImageFormat, webpQuality: Int): Bitmap.CompressFormat {
        return when (format) {
            ImageFormat.JPEG, ImageFormat.UNKNOWN -> Bitmap.CompressFormat.JPEG
            ImageFormat.PNG -> Bitmap.CompressFormat.PNG
            ImageFormat.WEBP -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (webpQuality >= 100) {
                        Bitmap.CompressFormat.WEBP_LOSSLESS
                    } else {
                        Bitmap.CompressFormat.WEBP_LOSSY
                    }
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
        }
    }
}
