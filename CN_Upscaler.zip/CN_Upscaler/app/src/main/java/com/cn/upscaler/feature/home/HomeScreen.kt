package com.cn.upscaler.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cn.upscaler.app.MainUiState
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.ai.ModelAvailability
import com.cn.upscaler.core.designsystem.AsyncUriThumbnail
import com.cn.upscaler.core.designsystem.StatusBadge
import com.cn.upscaler.core.designsystem.formatBytes
import com.cn.upscaler.core.image.SafeBitmapDecoder
import com.cn.upscaler.core.processing.TargetResolution
import com.cn.upscaler.domain.model.JobStatus

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    uiState: MainUiState,
    bitmapDecoder: SafeBitmapDecoder,
    onAddImagesClick: () -> Unit,
    onSelectTargetResolution: (TargetResolution) -> Unit,
    onSelectEnhancementLevel: (EnhancementLevel) -> Unit,
    onOpenProcessingQueue: () -> Unit,
    onOpenResult: (String) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "CN Upscaler",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Offline AI Image Super Resolution",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onAddImagesClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add Images", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Genuine AI Model Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val isAvailable = uiState.modelAvailability is ModelAvailability.Available
                    Icon(
                        imageVector = if (isAvailable) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = if (isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isAvailable) "On-Device AI Model Verified" else "AI Model Required for Processing",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                when (val avail = uiState.modelAvailability) {
                    is ModelAvailability.Available -> {
                        Text(
                            text = "${avail.spec.displayName} (${avail.spec.version}) • SHA-256: ${avail.sha256Digest} • ${formatBytes(avail.fileSizeBytes)}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Input: ${avail.inputTensorName} ${avail.inputShapeDescription} -> Output: ${avail.outputTensorName} ${avail.outputShapeDescription}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    is ModelAvailability.Unavailable -> {
                        Text(
                            text = avail.reason,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(onClick = onOpenSettings) {
                            Icon(Icons.Default.Memory, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Import ONNX Model in Settings")
                        }
                    }
                }
            }
        }

        // Quick Resolution & AI Enhancement Access Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Quick Output & AI Profile Defaults", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Target Resolution (Controls final pixel dimensions):",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    TargetResolution.entries.forEach { target ->
                        FilterChip(
                            selected = uiState.settings.defaultTargetResolution == target,
                            onClick = { onSelectTargetResolution(target) },
                            label = { Text(target.shortLabel) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "AI Enhancement Level (Controls neural processing profile, independent of dimensions):",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    EnhancementLevel.entries.forEach { level ->
                        val profile = uiState.enhancementProfiles.find { it.level == level }
                        val enabled = profile?.isAvailable ?: (level != EnhancementLevel.LEVEL_16X)
                        FilterChip(
                            selected = uiState.settings.defaultEnhancementLevel == level,
                            onClick = { onSelectEnhancementLevel(level) },
                            enabled = enabled,
                            label = { Text(level.shortBadge) }
                        )
                    }
                }
            }
        }

        // Active Processing Queue Summary
        if (uiState.activeQueue.isNotEmpty()) {
            val activeJob = uiState.activeQueue.firstOrNull { it.status == JobStatus.PROCESSING }
                ?: uiState.activeQueue.first()
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenProcessingQueue() },
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Active Batch Queue (${uiState.activeQueue.size} remaining)",
                            style = MaterialTheme.typography.titleMedium
                        )
                        StatusBadge(activeJob.status)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${activeJob.originalFilename} • ${activeJob.currentStageText}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { activeJob.progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Recent Output Summaries
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Processing Summaries", style = MaterialTheme.typography.titleMedium)
                    OutlinedButton(onClick = onOpenHistory) {
                        Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("All History")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                val recentCompleted = uiState.historyJobs.take(3)
                if (recentCompleted.isEmpty()) {
                    Text(
                        text = "No processed images yet. Tap "Add Images" above to select photos for offline AI super-resolution.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    recentCompleted.forEach { job ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenResult(job.id) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncUriThumbnail(
                                uriString = job.outputUriString ?: job.inputUriString,
                                decoder = bitmapDecoder,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(job.originalFilename, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${job.originalWidth}×${job.originalHeight} -> ${job.outputWidth ?: "-"}×${job.outputHeight ?: "-"} (${job.targetResolution.shortLabel} • ${job.enhancementLevel.shortBadge})",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusBadge(job.status)
                        }
                    }
                }
            }
        }

        // Quick Footer Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onOpenSettings,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Settings, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Settings")
            }
            OutlinedButton(
                onClick = onOpenAbout,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Info, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("About & Privacy")
            }
        }
    }
}
