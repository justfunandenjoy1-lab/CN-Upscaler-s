package com.cn.upscaler.feature.processing

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cn.upscaler.app.MainUiState
import com.cn.upscaler.core.designsystem.AsyncUriThumbnail
import com.cn.upscaler.core.designsystem.StatusBadge
import com.cn.upscaler.core.image.SafeBitmapDecoder
import com.cn.upscaler.domain.model.JobStatus
import com.cn.upscaler.domain.model.UpscaleJob
import kotlin.math.roundToInt

@Composable
fun ProcessingScreen(
    uiState: MainUiState,
    bitmapDecoder: SafeBitmapDecoder,
    onCancelJob: (String) -> Unit,
    onCancelAll: () -> Unit,
    onRetryJob: (String) -> Unit,
    onOpenResult: (String) -> Unit
) {
    val activeQueue = uiState.activeQueue
    val recentFinished = uiState.historyJobs.take(10)
    val completedCount = uiState.historyJobs.count { it.status == JobStatus.COMPLETED }
    val totalTracked = activeQueue.size + completedCount

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Batch Processing Queue", style = MaterialTheme.typography.titleLarge)
                Text(
                    text = if (activeQueue.isNotEmpty()) {
                        "Processing images... $completedCount / ${totalTracked.coerceAtLeast(1)} completed"
                    } else {
                        "Queue idle ($completedCount completed in history)"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (activeQueue.isNotEmpty()) {
                OutlinedButton(onClick = onCancelAll) {
                    Icon(Icons.Default.Cancel, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Cancel All")
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (activeQueue.isNotEmpty()) {
                item {
                    Text(
                        text = "Active & Waiting (${activeQueue.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                items(activeQueue, key = { it.id }) { job ->
                    BatchJobCard(
                        job = job,
                        bitmapDecoder = bitmapDecoder,
                        onCancel = { onCancelJob(job.id) },
                        onRetry = { onRetryJob(job.id) },
                        onClick = {}
                    )
                }
            }

            if (recentFinished.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Recently Completed / Finished",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                items(recentFinished, key = { it.id }) { job ->
                    BatchJobCard(
                        job = job,
                        bitmapDecoder = bitmapDecoder,
                        onCancel = { onCancelJob(job.id) },
                        onRetry = { onRetryJob(job.id) },
                        onClick = { onOpenResult(job.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun BatchJobCard(
    job: UpscaleJob,
    bitmapDecoder: SafeBitmapDecoder,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = job.status == JobStatus.COMPLETED) { onClick() }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncUriThumbnail(
                    uriString = job.outputUriString ?: job.inputUriString,
                    decoder = bitmapDecoder,
                    modifier = Modifier.size(60.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = job.originalFilename,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        StatusBadge(job.status)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Original: ${job.originalWidth}×${job.originalHeight} • Target: ${job.targetResolution.shortLabel} • Profile: ${job.enhancementLevel.shortBadge} • Format: ${job.outputFormat.displayName}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = job.currentStageText,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (job.errorDetails != null) {
                        Text(
                            text = job.errorDetails,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                if (job.status == JobStatus.WAITING || job.status == JobStatus.PROCESSING) {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Default.Cancel, contentDescription = "Cancel job")
                    }
                } else if (job.status == JobStatus.FAILED || job.status == JobStatus.CANCELLED) {
                    IconButton(onClick = onRetry) {
                        Icon(Icons.Default.Refresh, contentDescription = "Retry job")
                    }
                }
            }

            if (job.status == JobStatus.PROCESSING || job.status == JobStatus.WAITING) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LinearProgressIndicator(
                        progress = { job.progress },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${(job.progress * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
    }
}
