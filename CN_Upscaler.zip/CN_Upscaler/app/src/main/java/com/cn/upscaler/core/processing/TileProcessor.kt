package com.cn.upscaler.core.processing

import com.cn.upscaler.core.ai.TileSuperResolutionInferenceSession
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.ensureActive

data class TileConfig(
    val tileSize: Int = 256,
    val overlap: Int = 32
) {
    init {
        require(tileSize in 64..1024) { "tileSize must be between 64 and 1024 ($tileSize)" }
        require(overlap in 0..(tileSize / 3)) { "overlap ($overlap) must be between 0 and tileSize/3" }
    }
}

data class TileWindow(
    val tileIndex: Int,
    val gridX: Int,
    val gridY: Int,
    val srcX: Int,
    val srcY: Int,
    val srcWidth: Int,
    val srcHeight: Int,
    val dstX: Int,
    val dstY: Int,
    val dstWidth: Int,
    val dstHeight: Int,
    val hasLeftOverlap: Boolean,
    val hasRightOverlap: Boolean,
    val hasTopOverlap: Boolean,
    val hasBottomOverlap: Boolean
)

/**
 * Memory-safe Tile-Based Super-Resolution Processor.
 *
 * Features:
 * - Splits arbitrary source images into overlapping tiles (`tileSize`, default 256px, `overlap`, default 32px).
 * - Maps tile coordinates accurately to `(srcWidth * scale, srcHeight * scale)` output coordinates.
 * - Uses 1D/2D raised-cosine (Hann window ramp) weights across overlap margins so adjacent tiles
 *   sum to exact unity (`w_A(x) + w_B(x) = 1.0`), eliminating visible tile seams.
 * - Checks `coroutineContext.ensureActive()` between every tile for cooperative cancellation.
 */
object TileProcessor {

    fun computeTileGrid(
        srcWidth: Int,
        srcHeight: Int,
        scale: Int,
        config: TileConfig
    ): List<TileWindow> {
        require(srcWidth > 0 && srcHeight > 0) { "Source dimensions must be positive" }
        require(scale > 0) { "Scale must be positive" }

        val step = config.tileSize - config.overlap
        val xStarts = computeAxisStarts(srcWidth, config.tileSize, step)
        val yStarts = computeAxisStarts(srcHeight, config.tileSize, step)

        val windows = ArrayList<TileWindow>(xStarts.size * yStarts.size)
        var index = 0
        for ((gy, y0) in yStarts.withIndex()) {
            val th = min(config.tileSize, srcHeight - y0)
            for ((gx, x0) in xStarts.withIndex()) {
                val tw = min(config.tileSize, srcWidth - x0)
                windows += TileWindow(
                    tileIndex = index++,
                    gridX = gx,
                    gridY = gy,
                    srcX = x0,
                    srcY = y0,
                    srcWidth = tw,
                    srcHeight = th,
                    dstX = x0 * scale,
                    dstY = y0 * scale,
                    dstWidth = tw * scale,
                    dstHeight = th * scale,
                    hasLeftOverlap = gx > 0 && config.overlap > 0,
                    hasRightOverlap = gx < xStarts.lastIndex && config.overlap > 0,
                    hasTopOverlap = gy > 0 && config.overlap > 0,
                    hasBottomOverlap = gy < yStarts.lastIndex && config.overlap > 0
                )
            }
        }
        return windows
    }

    private fun computeAxisStarts(length: Int, tileSize: Int, step: Int): List<Int> {
        if (length <= tileSize) return listOf(0)
        val starts = mutableListOf<Int>()
        var pos = 0
        while (pos + tileSize < length) {
            starts += pos
            pos += step
        }
        val lastStart = max(0, length - tileSize)
        if (starts.isEmpty() || starts.last() != lastStart) {
            starts += lastStart
        }
        return starts
    }

    /**
     * Computes a 1D raised-cosine feathering weight profile of length `tileLengthPx`
     * with smooth cosine ramps on overlapped edges.
     */
    fun computeAxisFeatherWeights(
        tileLengthPx: Int,
        overlapPx: Int,
        rampStart: Boolean,
        rampEnd: Boolean
    ): FloatArray {
        val weights = FloatArray(tileLengthPx) { 1.0f }
        if (overlapPx <= 0 || tileLengthPx <= overlapPx * 2) return weights

        if (rampStart) {
            for (i in 0 until overlapPx) {
                // Raised cosine from 0 -> 1 over [0, overlapPx - 1]
                val t = (i + 0.5) / overlapPx.toDouble()
                weights[i] = (0.5 * (1.0 - cos(PI * t))).toFloat().coerceIn(1e-4f, 1.0f)
            }
        }
        if (rampEnd) {
            for (i in 0 until overlapPx) {
                val t = (i + 0.5) / overlapPx.toDouble()
                val w = (0.5 * (1.0 - cos(PI * t))).toFloat().coerceIn(1e-4f, 1.0f)
                weights[tileLengthPx - 1 - i] = min(weights[tileLengthPx - 1 - i], w)
            }
        }
        return weights
    }

    /**
     * Executes tiled inference over a source ARGB_8888 pixel buffer and reconstructs the
     * seamless `(srcWidth * scale) x (srcHeight * scale)` ARGB_8888 output buffer.
     */
    suspend fun processTiledImage(
        srcArgb: IntArray,
        srcWidth: Int,
        srcHeight: Int,
        preserveAlpha: Boolean,
        config: TileConfig,
        session: TileSuperResolutionInferenceSession,
        onTileProgress: suspend (completedTiles: Int, totalTiles: Int) -> Unit = { _, _ -> }
    ): IntArray {
        val scale = session.modelSpec.nativeScale
        val outWidth = srcWidth * scale
        val outHeight = srcHeight * scale
        val outSize = outWidth * outHeight

        val windows = computeTileGrid(srcWidth, srcHeight, scale, config)
        val totalTiles = windows.size

        // Fast path for single-tile images (no overlap blending overhead needed)
        if (totalTiles == 1) {
            coroutineContext.ensureActive()
            val single = windows.first()
            val outTile = session.inferTile(srcArgb, single.srcWidth, single.srcHeight, preserveAlpha)
            onTileProgress(1, 1)
            return outTile
        }

        // Accumulate weighted channels using compact fixed-point / float accumulators
        val accR = FloatArray(outSize)
        val accG = FloatArray(outSize)
        val accB = FloatArray(outSize)
        val accA = if (preserveAlpha) FloatArray(outSize) else null
        val accW = FloatArray(outSize)

        val scaledOverlap = config.overlap * scale

        for ((idx, win) in windows.withIndex()) {
            coroutineContext.ensureActive()

            // Extract source tile
            val tilePixels = IntArray(win.srcWidth * win.srcHeight)
            for (ty in 0 until win.srcHeight) {
                val srcRowStart = (win.srcY + ty) * srcWidth + win.srcX
                System.arraycopy(srcArgb, srcRowStart, tilePixels, ty * win.srcWidth, win.srcWidth)
            }

            // Run AI Super-Resolution inference on this tile
            val upscaledTile = session.inferTile(
                argbPixels = tilePixels,
                tileWidth = win.srcWidth,
                tileHeight = win.srcHeight,
                preserveAlpha = preserveAlpha
            )

            // Compute separable 1D cosine feather weights for X and Y
            val wx = computeAxisFeatherWeights(
                tileLengthPx = win.dstWidth,
                overlapPx = scaledOverlap,
                rampStart = win.hasLeftOverlap,
                rampEnd = win.hasRightOverlap
            )
            val wy = computeAxisFeatherWeights(
                tileLengthPx = win.dstHeight,
                overlapPx = scaledOverlap,
                rampStart = win.hasTopOverlap,
                rampEnd = win.hasBottomOverlap
            )

            // Blend upscaled tile into output accumulator
            for (ty in 0 until win.dstHeight) {
                val weightY = wy[ty]
                val dstRowOffset = (win.dstY + ty) * outWidth + win.dstX
                val tileRowOffset = ty * win.dstWidth
                for (tx in 0 until win.dstWidth) {
                    val w = weightY * wx[tx]
                    val pixel = upscaledTile[tileRowOffset + tx]
                    val a = (pixel ushr 24) and 0xFF
                    val r = (pixel ushr 16) and 0xFF
                    val g = (pixel ushr 8) and 0xFF
                    val b = pixel and 0xFF

                    val outIdx = dstRowOffset + tx
                    accR[outIdx] += r * w
                    accG[outIdx] += g * w
                    accB[outIdx] += b * w
                    if (accA != null) {
                        accA[outIdx] += a * w
                    }
                    accW[outIdx] += w
                }
            }

            onTileProgress(idx + 1, totalTiles)
        }

        coroutineContext.ensureActive()

        // Normalize accumulated weighted values back to packed ARGB_8888
        val resultArgb = IntArray(outSize)
        for (i in 0 until outSize) {
            val w = accW[i].coerceAtLeast(1e-6f)
            val r = (accR[i] / w).roundToInt().coerceIn(0, 255)
            val g = (accG[i] / w).roundToInt().coerceIn(0, 255)
            val b = (accB[i] / w).roundToInt().coerceIn(0, 255)
            val a = if (accA != null) (accA[i] / w).roundToInt().coerceIn(0, 255) else 0xFF
            resultArgb[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }

        return resultArgb
    }
}
