package com.cn.upscaler.data.repository

import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.database.JobDao
import com.cn.upscaler.core.database.JobEntity
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.processing.TargetResolution
import com.cn.upscaler.domain.model.JobStatus
import com.cn.upscaler.domain.model.SelectedImageCandidate
import com.cn.upscaler.domain.model.UpscaleJob
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class JobRepository(
    private val jobDao: JobDao
) {
    val allJobsFlow: Flow<List<UpscaleJob>> =
        jobDao.observeAllJobs().map { list -> list.map { it.toDomain() } }

    val activeQueueFlow: Flow<List<UpscaleJob>> =
        jobDao.observeActiveQueue().map { list -> list.map { it.toDomain() } }

    val historyFlow: Flow<List<UpscaleJob>> =
        jobDao.observeHistory().map { list -> list.map { it.toDomain() } }

    suspend fun enqueueBatch(
        candidates: List<SelectedImageCandidate>,
        targetResolution: TargetResolution,
        enhancementLevel: EnhancementLevel,
        outputFormat: ImageFormat,
        jpegQuality: Int
    ): List<UpscaleJob> {
        val baseTime = System.currentTimeMillis()
        val jobs = candidates.mapNotNull { candidate ->
            val report = candidate.inspectionReport ?: return@mapNotNull null
            UpscaleJob(
                id = UUID.randomUUID().toString(),
                inputUriString = candidate.uriString,
                outputUriString = null,
                originalFilename = report.filename,
                originalWidth = report.orientedWidth,
                originalHeight = report.orientedHeight,
                originalFormat = report.format,
                originalFileSizeBytes = report.fileSizeBytes,
                hasAlpha = report.hasAlpha,
                targetResolution = targetResolution,
                enhancementLevel = enhancementLevel,
                outputFormat = outputFormat,
                jpegQuality = jpegQuality,
                status = JobStatus.WAITING,
                progress = 0f,
                currentStageText = "Waiting in batch queue",
                createdAtMillis = baseTime + candidates.indexOf(candidate),
                startTimeMillis = null,
                completionTimeMillis = null,
                outputWidth = null,
                outputHeight = null,
                outputFileSizeBytes = null,
                actualModelName = null,
                actualModelVersion = null,
                actualProcessingStages = null,
                activeExecutionProvider = null,
                errorDetails = null,
                warningsSummary = candidate.validationWarnings.joinToString(" | ").ifBlank { null }
            )
        }
        jobDao.insertJobs(jobs.map { JobEntity.fromDomain(it) })
        return jobs
    }

    suspend fun getJobById(jobId: String): UpscaleJob? =
        jobDao.getJobById(jobId)?.toDomain()

    suspend fun getNextWaitingJob(): UpscaleJob? =
        jobDao.getNextWaitingJob()?.toDomain()

    suspend fun countWaitingJobs(): Int =
        jobDao.countWaitingJobs()

    suspend fun updateJob(job: UpscaleJob) {
        jobDao.updateJob(JobEntity.fromDomain(job))
    }

    suspend fun cancelJob(jobId: String) {
        jobDao.cancelJobById(jobId, System.currentTimeMillis())
    }

    suspend fun cancelAllActiveAndWaiting() {
        jobDao.cancelAllPendingAndActive(System.currentTimeMillis())
    }

    suspend fun retryJob(jobId: String) {
        val existing = jobDao.getJobById(jobId)?.toDomain() ?: return
        if (existing.status == JobStatus.FAILED || existing.status == JobStatus.CANCELLED) {
            val reset = existing.copy(
                status = JobStatus.WAITING,
                progress = 0f,
                currentStageText = "Waiting in batch queue (retry)",
                startTimeMillis = null,
                completionTimeMillis = null,
                errorDetails = null
            )
            jobDao.updateJob(JobEntity.fromDomain(reset))
        }
    }

    suspend fun deleteJob(jobId: String) {
        jobDao.deleteJobById(jobId)
    }

    suspend fun clearHistory() {
        jobDao.clearFinishedHistory()
    }

    suspend fun recoverInterruptedJobsOnStartup(): Int {
        return jobDao.resetInterruptedProcessingJobsToWaiting()
    }
}
