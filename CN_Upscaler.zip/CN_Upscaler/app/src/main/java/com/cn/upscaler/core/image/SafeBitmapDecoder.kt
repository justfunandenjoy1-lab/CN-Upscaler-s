package com.cn.upscaler.core.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorSpace
import android.net.Uri
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.common.ErrorCode
import com.cn.upscaler.core.common.MemoryBudgetMonitor

/**
 * Memory-safe Bitmap decoder supporting subsampled thumbnail decoding for UI previews
 * and full/capped sRGB ARGB_8888 decoding for AI super-resolution processing.
 */
class SafeBitmapDecoder(
    private val context: Context,
    private val memoryMonitor: MemoryBudgetMonitor
) {
    /**
     * Decodes a memory-safe subsampled thumbnail (never decoding full resolution just for UI).
     */
    fun decodeThumbnail(uri: Uri, maxDimensionPx: Int = 256): AppResult<Bitmap> {
        return try {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOptions)
            } ?: return AppResult.Error("Cannot open URI for thumbnail", errorCode = ErrorCode.FILE_NOT_FOUND)

            if (boundsOptions.outWidth <= 0 || boundsOptions.outHeight <= 0) {
                return AppResult.Error("Invalid image dimensions", errorCode = ErrorCode.CORRUPTED_IMAGE)
            }

            val sampleSize = calculateInSampleSize(
                boundsOptions.outWidth,
                boundsOptions.outHeight,
                maxDimensionPx,
                maxDimensionPx
            )
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val rawBitmap = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            } ?: return AppResult.Error("Failed to decode thumbnail stream", errorCode = ErrorCode.CORRUPTED_IMAGE)

            val exifOrientation = readExifOrientation(uri)
            val oriented = ExifOrientationHelper.applyOrientation(rawBitmap, exifOrientation)
            AppResult.Success(oriented)
        } catch (oom: OutOfMemoryError) {
            System.gc()
            AppResult.Error("Insufficient memory decoding thumbnail", oom, ErrorCode.INSUFFICIENT_MEMORY)
        } catch (t: Throwable) {
            AppResult.Error("Thumbnail decode failure: ${t.message}", t, ErrorCode.CORRUPTED_IMAGE)
        }
    }

    /**
     * Decodes a source Bitmap in ARGB_8888 sRGB color space with EXIF orientation applied.
     */
    fun decodeForProcessing(uri: Uri, report: ImageInspectionReport): AppResult<Bitmap> {
        if (!memoryMonitor.isSafeSingleBitmapAllocation(report.rawWidth, report.rawHeight)) {
            return AppResult.Error(
                "Source image (${report.rawWidth}×${report.rawHeight}) exceeds safe single-bitmap heap budget.",
                errorCode = ErrorCode.INSUFFICIENT_MEMORY
            )
        }
        return try {
            val decodeOptions = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inPreferredColorSpace = ColorSpace.get(ColorSpace.Named.SRGB)
                inMutable = false
            }
            val rawBitmap = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            } ?: return AppResult.Error("Failed to open image stream", errorCode = ErrorCode.FILE_NOT_FOUND)

            val oriented = ExifOrientationHelper.applyOrientation(rawBitmap, report.exifOrientation)
            AppResult.Success(oriented)
        } catch (oom: OutOfMemoryError) {
            System.gc()
            AppResult.Error("Out of memory while decoding source image.", oom, ErrorCode.INSUFFICIENT_MEMORY)
        } catch (t: Throwable) {
            AppResult.Error("Failed to decode source image: ${t.message}", t, ErrorCode.CORRUPTED_IMAGE)
        }
    }

    private fun readExifOrientation(uri: Uri): Int {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                androidx.exifinterface.media.ExifInterface(stream).getAttributeInt(
                    androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
                )
            } ?: androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
        } catch (_: Throwable) {
            androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
        }
    }

    companion object {
        fun calculateInSampleSize(srcWidth: Int, srcHeight: Int, reqWidth: Int, reqHeight: Int): Int {
            var inSampleSize = 1
            if (srcHeight > reqHeight || srcWidth > reqWidth) {
                val halfHeight = srcHeight / 2
                val halfWidth = srcWidth / 2
                while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                    inSampleSize *= 2
                }
            }
            return inSampleSize.coerceAtLeast(1)
        }
    }
}
