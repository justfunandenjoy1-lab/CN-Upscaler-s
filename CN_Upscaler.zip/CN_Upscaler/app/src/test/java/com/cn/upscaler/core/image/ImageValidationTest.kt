package com.cn.upscaler.core.image

import androidx.exifinterface.media.ExifInterface
import com.cn.upscaler.core.common.ErrorCode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ImageValidationTest {

    @Test
    fun `valid 16x9 JPEG passes validation and computes accurate memory`() {
        val result = ImageValidationRules.validateBounds(
            uriString = "content://media/external/images/media/101",
            filename = "sample_landscape.jpg",
            rawWidth = 1920,
            rawHeight = 1080,
            exifOrientation = ExifInterface.ORIENTATION_NORMAL,
            format = ImageFormat.JPEG,
            hasAlpha = false,
            fileSizeBytes = 1_450_000L,
            availableHeapBytes = 512L * 1024L * 1024L
        )
        assertTrue(result is ImageValidationResult.Valid)
        val report = (result as ImageValidationResult.Valid).report
        assertEquals(1920, report.orientedWidth)
        assertEquals(1080, report.orientedHeight)
        assertEquals("16:9", report.aspectRatioLabel)
        assertEquals(1920L * 1080L * 4L, report.decodedMemoryBytes)
    }

    @Test
    fun `EXIF 90 degree rotation swaps oriented width and height`() {
        val result = ImageValidationRules.validateBounds(
            uriString = "content://media/external/images/media/102",
            filename = "portrait_exif.jpg",
            rawWidth = 4000,
            rawHeight = 3000,
            exifOrientation = ExifInterface.ORIENTATION_ROTATE_90,
            format = ImageFormat.JPEG,
            hasAlpha = false,
            fileSizeBytes = 3_200_000L,
            availableHeapBytes = 512L * 1024L * 1024L
        )
        assertTrue(result is ImageValidationResult.Valid)
        val report = (result as ImageValidationResult.Valid).report
        assertEquals(3000, report.orientedWidth)
        assertEquals(4000, report.orientedHeight)
        assertEquals("3:4", report.aspectRatioLabel)
    }

    @Test
    fun `corrupted zero dimensions are rejected with CORRUPTED_IMAGE`() {
        val result = ImageValidationRules.validateBounds(
            uriString = "content://media/external/images/media/103",
            filename = "corrupted.png",
            rawWidth = -1,
            rawHeight = 0,
            exifOrientation = ExifInterface.ORIENTATION_NORMAL,
            format = ImageFormat.PNG,
            hasAlpha = false,
            fileSizeBytes = 1024L,
            availableHeapBytes = 256L * 1024L * 1024L
        )
        assertTrue(result is ImageValidationResult.Invalid)
        assertEquals(ErrorCode.CORRUPTED_IMAGE, (result as ImageValidationResult.Invalid).errorCode)
    }

    @Test
    fun `unsupported format is rejected with UNSUPPORTED_FORMAT`() {
        val fmt = ImageFormat.fromMimeTypeOrName("image/bmp", "legacy.bmp")
        val result = ImageValidationRules.validateBounds(
            uriString = "content://media/external/images/media/104",
            filename = "legacy.bmp",
            rawWidth = 800,
            rawHeight = 600,
            exifOrientation = ExifInterface.ORIENTATION_NORMAL,
            format = fmt,
            hasAlpha = false,
            fileSizeBytes = 500_000L,
            availableHeapBytes = 256L * 1024L * 1024L
        )
        assertTrue(result is ImageValidationResult.Invalid)
        assertEquals(ErrorCode.UNSUPPORTED_FORMAT, (result as ImageValidationResult.Invalid).errorCode)
    }

    @Test
    fun `extremely large source exceeding 16384px is rejected with DIMENSION_LIMIT_EXCEEDED`() {
        val result = ImageValidationRules.validateBounds(
            uriString = "content://media/external/images/media/105",
            filename = "huge.png",
            rawWidth = 20000,
            rawHeight = 12000,
            exifOrientation = ExifInterface.ORIENTATION_NORMAL,
            format = ImageFormat.PNG,
            hasAlpha = false,
            fileSizeBytes = 25_000_000L,
            availableHeapBytes = 512L * 1024L * 1024L
        )
        assertTrue(result is ImageValidationResult.Invalid)
        assertEquals(ErrorCode.DIMENSION_LIMIT_EXCEEDED, (result as ImageValidationResult.Invalid).errorCode)
    }
}
