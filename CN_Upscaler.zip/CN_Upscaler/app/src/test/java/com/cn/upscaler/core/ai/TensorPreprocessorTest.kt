package com.cn.upscaler.core.ai

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class TensorPreprocessorTest {

    @Test
    fun `computeAlignedDimension pads non-multiples of 4 up to next multiple of 4`() {
        assertEquals(4, TensorPreprocessor.computeAlignedDimension(1, 4))
        assertEquals(4, TensorPreprocessor.computeAlignedDimension(4, 4))
        assertEquals(256, TensorPreprocessor.computeAlignedDimension(255, 4))
        assertEquals(256, TensorPreprocessor.computeAlignedDimension(256, 4))
    }

    @Test
    fun `preprocessTile constructs NCHW float32 RGB in 0 to 1 range with reflection padding`() {
        val spec = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS
        // 3x2 pixel tile -> should pad to 4x4
        val pixels = IntArray(3 * 2) {
            (0x80 shl 24) or (255 shl 16) or (128 shl 8) or 0
        }
        val prepared = TensorPreprocessor.preprocessTile(
            argbPixels = pixels,
            width = 3,
            height = 2,
            spec = spec,
            preserveAlpha = true
        )
        assertArrayEquals(longArrayOf(1L, 3L, 4L, 4L), prepared.tensorShape)
        assertEquals(4, prepared.paddedWidth)
        assertEquals(4, prepared.paddedHeight)
        assertEquals(1, prepared.padRight)
        assertEquals(2, prepared.padBottom)

        // Verify R=1.0f, G=128/255f, B=0.0f across NCHW planes
        val planeSize = 4 * 4
        assertEquals(1.0f, prepared.floatData[0], 1e-4f)
        assertEquals(128f / 255f, prepared.floatData[planeSize], 1e-4f)
        assertEquals(0.0f, prepared.floatData[2 * planeSize], 1e-4f)
    }

    @Test
    fun `postprocessTile unpads 4x output tensor and restores alpha channel`() {
        val spec = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS
        val pixels = IntArray(4 * 4) {
            (200 shl 24) or (64 shl 16) or (128 shl 8) or 255
        }
        val prepared = TensorPreprocessor.preprocessTile(
            argbPixels = pixels,
            width = 4,
            height = 4,
            spec = spec,
            preserveAlpha = true
        )
        val outW = 16
        val outH = 16
        val plane = outW * outH
        val fakeModelOut = FloatArray(3 * plane)
        for (i in 0 until plane) {
            fakeModelOut[i] = 64f / 255f
            fakeModelOut[plane + i] = 128f / 255f
            fakeModelOut[2 * plane + i] = 1.0f
        }
        val outPixels = TensorPreprocessor.postprocessTile(fakeModelOut, prepared, spec)
        assertEquals(16 * 16, outPixels.size)
        val first = outPixels[0]
        assertEquals(200, (first ushr 24) and 0xFF)
        assertEquals(64, (first ushr 16) and 0xFF)
        assertEquals(128, (first ushr 8) and 0xFF)
        assertEquals(255, first and 0xFF)
    }
}
