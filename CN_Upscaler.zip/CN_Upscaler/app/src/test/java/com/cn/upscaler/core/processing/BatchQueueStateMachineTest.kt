package com.cn.upscaler.core.processing

import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.domain.model.JobStatus
import com.cn.upscaler.domain.model.UpscaleJob
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class BatchQueueStateMachineTest {

    private fun sampleJob(id: String, createdAt: Long): UpscaleJob = UpscaleJob(
        id = id,
        inputUriString = "content://test/$id",
        outputUriString = null,
        originalFilename = "$id.jpg",
        originalWidth = 1920,
        originalHeight = 1080,
        originalFormat = ImageFormat.JPEG,
        originalFileSizeBytes = 100_000L,
        hasAlpha = false,
        targetResolution = TargetResolution.UHD_4K,
        enhancementLevel = EnhancementLevel.LEVEL_4X,
        outputFormat = ImageFormat.JPEG,
        jpegQuality = 95,
        status = JobStatus.WAITING,
        progress = 0f,
        currentStageText = "Waiting",
        createdAtMillis = createdAt,
        startTimeMillis = null,
        completionTimeMillis = null,
        outputWidth = null,
        outputHeight = null,
        outputFileSizeBytes = null,
        actualModelName = null,
        actualModelVersion = null,
        actualProcessingStages = null,
        activeExecutionProvider = null,
        errorDetails = null,
        warningsSummary = null
    )

    @Test
    fun `queue enforces single active job and processes in FIFO order`() {
        val queue = BatchQueueStateMachine()
        queue.enqueue(
            listOf(
                sampleJob("job1", 1000L),
                sampleJob("job2", 2000L),
                sampleJob("job3", 3000L)
            )
        )

        val started1 = queue.pollNextWaitingJob(5000L)
        assertNotNull(started1)
        assertEquals("job1", started1?.id)
        assertEquals(JobStatus.PROCESSING, started1?.status)

        // Polling again while job1 is PROCESSING returns null (single-job concurrency guard)
        assertNull(queue.pollNextWaitingJob(5100L))

        // If job1 fails, job2 is still processed next and job3 remains WAITING
        queue.markFailed("job1", "Simulated corrupted tile", 6000L)
        val started2 = queue.pollNextWaitingJob(6100L)
        assertEquals("job2", started2?.id)

        queue.markCompleted(
            jobId = "job2",
            outputUriString = "content://media/external/images/media/999",
            outputWidth = 3840,
            outputHeight = 2160,
            outputFileSizeBytes = 2_400_000L,
            actualModelName = "Real-ESRGAN x4plus",
            actualModelVersion = "v0.1.0",
            actualStages = "SinglePass 4x",
            activeProvider = "CPU",
            warningsSummary = null,
            nowMillis = 7000L
        )

        // Cancel job3 before it starts
        queue.cancelJob("job3", 7100L)
        assertNull(queue.pollNextWaitingJob(7200L))

        val snapshot = queue.snapshot().associateBy { it.id }
        assertEquals(JobStatus.FAILED, snapshot["job1"]?.status)
        assertEquals(JobStatus.COMPLETED, snapshot["job2"]?.status)
        assertEquals(JobStatus.CANCELLED, snapshot["job3"]?.status)

        // Retry job1 transitions it back to WAITING
        queue.retryJob("job1")
        assertEquals(JobStatus.WAITING, queue.snapshot().first { it.id == "job1" }.status)
    }
}
