package com.cn.upscaler.core.processing

import com.cn.upscaler.core.ai.ActiveExecutionProviderReport
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.ai.SuperResolutionModelSpec
import com.cn.upscaler.core.ai.SupportedModelCatalog
import com.cn.upscaler.core.ai.TileSuperResolutionInferenceSession
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class TileProcessorTest {

    private class IdentityNearest4xSession : TileSuperResolutionInferenceSession {
        override val modelSpec: SuperResolutionModelSpec = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS
        override val activeProviderReport = ActiveExecutionProviderReport(
            requestedPreference = ExecutionProviderPreference.CPU_ONLY,
            activeProviderName = "TestCPU",
            fellBackToCpu = false,
            fallbackReason = null,
            threadCount = 1
        )

        override fun inferTile(
            argbPixels: IntArray,
            tileWidth: Int,
            tileHeight: Int,
            preserveAlpha: Boolean
        ): IntArray {
            val scale = modelSpec.nativeScale
            val outW = tileWidth * scale
            val outH = tileHeight * scale
            val out = IntArray(outW * outH)
            for (y in 0 until outH) {
                val sy = y / scale
                for (x in 0 until outW) {
                    val sx = x / scale
                    out[y * outW + x] = argbPixels[sy * tileWidth + sx]
                }
            }
            return out
        }

        override fun close() {}
    }

    @Test
    fun `computeTileGrid covers entire source image including right and bottom edges`() {
        val config = TileConfig(tileSize = 128, overlap = 32)
        val grid = TileProcessor.computeTileGrid(srcWidth = 300, srcHeight = 250, scale = 4, config = config)
        assertTrue(grid.size >= 6)
        assertEquals(300, grid.maxOf { it.srcX + it.srcWidth })
        assertEquals(250, grid.maxOf { it.srcY + it.srcHeight })
        assertEquals(1200, grid.maxOf { it.dstX + it.dstWidth })
        assertEquals(1000, grid.maxOf { it.dstY + it.dstHeight })
    }

    @Test
    fun `processTiledImage reconstructs multi-tile image without seams or missing pixels`() = runTest {
        val srcW = 200
        val srcH = 160
        val constantColor = (0xFF shl 24) or (90 shl 16) or (140 shl 8) or 210
        val src = IntArray(srcW * srcH) { constantColor }
        val config = TileConfig(tileSize = 96, overlap = 16)

        val out = TileProcessor.processTiledImage(
            srcArgb = src,
            srcWidth = srcW,
            srcHeight = srcH,
            preserveAlpha = false,
            config = config,
            session = IdentityNearest4xSession()
        )
        assertEquals((srcW * 4) * (srcH * 4), out.size)
        for (px in out) {
            val r = (px ushr 16) and 0xFF
            val g = (px ushr 8) and 0xFF
            val b = px and 0xFF
            assertTrue(abs(r - 90) <= 1)
            assertTrue(abs(g - 140) <= 1)
            assertTrue(abs(b - 210) <= 1)
        }
    }
}
