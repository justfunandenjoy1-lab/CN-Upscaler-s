package com.cn.upscaler.core.processing

import com.cn.upscaler.core.ai.EnhancementLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ResolutionCalculatorTest {

    @Test
    fun `16x9 landscape 1920x1080 to 2K 4K 8K 16K matches exact UHD reference dimensions`() {
        val p2k = ResolutionCalculator.calculate(1920, 1080, TargetResolution.UHD_2K)
        assertEquals(2560, p2k.outputWidth)
        assertEquals(1440, p2k.outputHeight)

        val p4k = ResolutionCalculator.calculate(1920, 1080, TargetResolution.UHD_4K)
        assertEquals(3840, p4k.outputWidth)
        assertEquals(2160, p4k.outputHeight)

        val p8k = ResolutionCalculator.calculate(1920, 1080, TargetResolution.UHD_8K)
        assertEquals(7680, p8k.outputWidth)
        assertEquals(4320, p8k.outputHeight)

        val p16k = ResolutionCalculator.calculate(1920, 1080, TargetResolution.UHD_16K)
        assertEquals(15360, p16k.outputWidth)
        assertEquals(8640, p16k.outputHeight)
    }

    @Test
    fun `independence check - 1920x1080 with Target 4K and 8x AI Enhancement remains 3840x2160`() {
        // Verifies Critical Definition C: Target Resolution controls final dimensions,
        // independent of AI Enhancement Level (4x, 8x, 16x).
        val enhancementLevel = EnhancementLevel.LEVEL_8X
        val plan = ResolutionCalculator.calculate(1920, 1080, TargetResolution.UHD_4K)
        assertEquals("ENHANCE_8X", enhancementLevel.id)
        assertEquals(3840, plan.outputWidth)
        assertEquals(2160, plan.outputHeight)
    }

    @Test
    fun `portrait 9x16 image 1080x1920 to 4K UHD preserves portrait ratio at 2160x3840`() {
        val plan = ResolutionCalculator.calculate(1080, 1920, TargetResolution.UHD_4K)
        assertEquals(2160, plan.outputWidth)
        assertEquals(3840, plan.outputHeight)
    }

    @Test
    fun `square 1x1 image 1000x1000 to 4K UHD fits within short reference side 2160x2160`() {
        val plan = ResolutionCalculator.calculate(1000, 1000, TargetResolution.UHD_4K)
        assertEquals(2160, plan.outputWidth)
        assertEquals(2160, plan.outputHeight)
    }

    @Test
    fun `4x3 image 1600x1200 to 4K UHD preserves 4x3 aspect ratio at 2880x2160`() {
        val plan = ResolutionCalculator.calculate(1600, 1200, TargetResolution.UHD_4K)
        assertEquals(2880, plan.outputWidth)
        assertEquals(2160, plan.outputHeight)
    }

    @Test
    fun `unusual ultrawide 21x9 image 2520x1080 to 4K UHD fits width at 3840x1646 without distortion`() {
        val plan = ResolutionCalculator.calculate(2520, 1080, TargetResolution.UHD_4K)
        assertEquals(3840, plan.outputWidth)
        assertEquals(1646, plan.outputHeight)
        val srcRatio = 2520.0 / 1080.0
        val outRatio = plan.outputWidth.toDouble() / plan.outputHeight.toDouble()
        assertTrue(abs(srcRatio - outRatio) < 0.002)
    }

    @Test
    fun `downscaling from 4000x2250 to 2K UHD sets isDownscalingFromSource and emits warning`() {
        val plan = ResolutionCalculator.calculate(4000, 2250, TargetResolution.UHD_2K)
        assertEquals(2560, plan.outputWidth)
        assertEquals(1440, plan.outputHeight)
        assertTrue(plan.isDownscalingFromSource)
        assertTrue(plan.warnings.any { it.contains("smaller than original") })
    }

    @Test
    fun `16K UHD on restricted 256MB heap flags exceedsMaximumSupportedOutput and suggests supported alternatives`() {
        val plan = ResolutionCalculator.calculate(
            sourceWidth = 1920,
            sourceHeight = 1080,
            target = TargetResolution.UHD_16K,
            availableHeapBytes = 256L * 1024L * 1024L
        )
        assertTrue(plan.exceedsSafeSingleBitmapLimit)
        assertTrue(plan.exceedsMaximumSupportedOutput)
        assertFalse(plan.supportedAlternatives.isEmpty())
        assertTrue(TargetResolution.UHD_2K in plan.supportedAlternatives)
    }
}
