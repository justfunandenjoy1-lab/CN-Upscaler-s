#!/usr/bin/env bash
set -euo pipefail

echo "============================================================"
echo " CN Upscaler (com.cn.upscaler) — Automated Test & APK Build"
echo "============================================================"

if ! command -v java >/dev/null 2>&1; then
    echo "ERROR: Java 17 (JDK 17) is required. Install OpenJDK 17 or Android Studio."
    exit 1
fi

if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
    echo "WARNING: ANDROID_HOME is not set. Ensure local.properties defines sdk.dir=/path/to/Android/sdk"
fi

GRADLE_CMD="./gradlew"
if command -v gradle >/dev/null 2>&1 && [ ! -f "gradle/wrapper/gradle-wrapper.jar" ]; then
    GRADLE_CMD="gradle"
fi

echo "[1/3] Running automated unit test suite (testDebugUnitTest)..."
$GRADLE_CMD testDebugUnitTest --stacktrace

echo "[2/3] Compiling Debug APK (assembleDebug)..."
$GRADLE_CMD assembleDebug --stacktrace

mkdir -p dist
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    cp "app/build/outputs/apk/debug/app-debug.apk" "dist/CN-Upscaler-debug.apk"
    echo "[3/3] SUCCESS: APK created at dist/CN-Upscaler-debug.apk"
fi
